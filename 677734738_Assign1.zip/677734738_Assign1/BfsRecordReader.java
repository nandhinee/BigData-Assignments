import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.LineRecordReader;
import org.apache.hadoop.mapred.RecordReader;

public class BfsRecordReader implements RecordReader<LongWritable, Text> {

	  private LineRecordReader lineReader;
	  private LongWritable lineKey;
	  private Text lineValue;
	public BfsRecordReader(JobConf job, FileSplit input) throws IOException {
		lineReader = new LineRecordReader (job,input);
		lineKey = lineReader.createKey();
		lineValue = lineReader.createValue();
	}	

	@Override
	public void close() throws IOException {
		lineReader.close();

	}

	@Override
	public LongWritable createKey() {
		// TODO Auto-generated method stub
		return new LongWritable();
	}

	@Override
	public Text createValue() {
		// TODO Auto-generated method stub
		return new Text("");
	}

	@Override
	public long getPos() throws IOException {
		// TODO Auto-generated method stub
		return lineReader.getPos();
	}

	@Override
	public float getProgress() throws IOException {
		// TODO Auto-generated method stub
		return lineReader.getProgress();
	}

	@Override
	public boolean next(LongWritable key, Text value) throws IOException {
		if (!lineReader.next(lineKey, lineValue)) {
		      return false;
		    }
		String [] pieces = lineValue.toString().split("\\t");
		if (pieces.length != 2) {
		      throw new IOException("Invalid record received");
		    }
		long s = Long.parseLong(pieces[0].trim());
		key.set((s));
		value.set(pieces[1].trim());
		
		return true;
	}

}