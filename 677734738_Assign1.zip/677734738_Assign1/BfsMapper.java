import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;




public class BfsMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

	public void map(WritableComparable key, Writable values,
			OutputCollector output, Reporter reporter) throws IOException {
	}

	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		// create a node for the input with the values and its corresponding key
		Node node = new Node(value.toString() , key.toString());
		// set the id for the new node with the key
		node.id=key.toString();
	
		//process only the Gray nodes
		if(node.color==Node.colors.GRAY){
			
			// for each adjacent nodes
			for (String adjnodes : node.getAdjnodes()) { 
				// create a new empty node with default values
				Node adjNode = new Node(); 
				// set the node id
				String adjid = adjNode.setId(adjnodes); 
				// set the distance of the node from it's parent
				adjNode.setDist(node.getDist() + 1); 
				// the node is visited
				adjNode.setColor(Node.colors.GRAY); 
				// set the adjacent node's parent as the current node 
				adjNode.setParent(node.getId());
				//generate all the node's details
				String nodeinfo = adjNode.printnodes();
				output.collect(new Text(adjid), new Text(nodeinfo));
			}			
			node.setColor(Node.colors.BLACK);
			Counter.cntr--;	
		}
		String id = node.getId();
		String values = node.printnodes();
		// sends the key value pairs to the reducer class BfsReducer.java
		output.collect(new Text(id), new Text(values));	
	}
}
