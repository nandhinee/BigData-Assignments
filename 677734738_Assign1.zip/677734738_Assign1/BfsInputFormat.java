// This class is created to separate the node number in the input as pass it as a key to the mapper
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;



public class BfsInputFormat extends
FileInputFormat<LongWritable,Text> {

public RecordReader<LongWritable, Text> getRecordReader(
  InputSplit input, JobConf job, Reporter reporter)
  throws IOException {

	reporter.setStatus(input.toString());
	//creates a new object for the class BfsRecordReader that separated the keys and values
	return new BfsRecordReader(job, (FileSplit)input);
}



}
