
public class Counter {
	//to track the counter variable
	public static int cntr=1;

}
