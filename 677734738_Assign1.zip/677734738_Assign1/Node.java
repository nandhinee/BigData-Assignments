import java.util.ArrayList;
import java.util.List;

public class Node {
	
	String id;									  // node id
	List<String> adjnodes = new ArrayList<String>(); // adjacent nodes are stored as array list
	int dist;									  // distance from source
	enum colors {WHITE,GRAY,BLACK};				
	colors color = colors.WHITE;				// by default the color is white
	String parent;								// parent of the node
	
	public String getId() {
		return id;
	}

	public String setId(String id) {
		this.id = id;
		return this.id;
	}

	public List<String> getAdjnodes() {
		return adjnodes;
	}

	public void setAdjnodes(List<String> adjnodes) {
		this.adjnodes = adjnodes;
	}

	public int getDist() {
		return dist;
	}

	public void setDist(int dist) {
		this.dist = dist;
	}

	public colors getColor() {
		return color;
	}

	public void setColor(colors color) {
		this.color = color;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
	//empty node with default values
	Node()
	{
		adjnodes = new ArrayList<String>();
        dist = Integer.MAX_VALUE;
        color = colors.WHITE;
        parent = null;

	}

	Node(String inputnode , String nodeid){	
		String str = inputnode.toString(); //contains the whole node details
		this.id=nodeid; 		//set the node id
		String[] nodedata = str.split("\\|"); //nodedata[0] = adjlist, nodedata[1]=dist, nodedata[2]=color, nodedata[3]=parent
		String[] adjlist = nodedata[0].split(",");
		for(int i =0; i<adjlist.length; i++)
			adjnodes.add(adjlist[i]);
		// To determine the source node and assign default values to it
		// When the source node matches with the node id only for the 1st iteration
		if(Bfs.srcNode==Integer.parseInt(this.id.toString()) &&  Bfs.jobcount==1){
			nodedata[1]= "0";
			nodedata[3]="source";
		}
		if (nodedata[1].equals("Integer.MAX_VALUE")) {
            this.dist = Integer.MAX_VALUE;
        } else {
            this.dist = Integer.parseInt(nodedata[1]);
        }
        // setting the color of the source node
		// When the source node matches with the node id only for the 1st iteration
		if(Bfs.srcNode==Integer.parseInt(this.id.toString()) && Bfs.jobcount==1)
		{
			this.color=colors.GRAY;
			Bfs.jobcount++;
		}
		else 
			this.color = color.valueOf(nodedata[2]);
        // setting the parent of the node	
        this.parent = nodedata[3];
	}
	
	public String printnodes(){
		String s = new String();
		//join all the adjacent nodes
		for (String str : adjnodes) 
			s=s+str+",";
			s=s+"|";
        //join the distance of the node from its source
        if (this.dist < Integer.MAX_VALUE) {
        	s=s+this.dist+"|";
        } else {
        	s=s+"Integer.MAX_VALUE"+"|";
        }
        // join the node color
        s=s+color.toString()+"|";
        // join the node's parent
        s=s+getParent();
        return s; 
	}
}
