import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Partitioner;


public class BfsPartitioner extends MapReduceBase implements Partitioner<Text,Text>{

	@Override
	public int getPartition(Text key, Text value, int numReduceTasks) {
		// TODO Auto-generated method stub
		int id= Integer.parseInt(key.toString());	
		
		// to avoid mod 0
		if(numReduceTasks == 0)
			return 0;
		
		
		if ( id<=30)
		{
			return 0;
		}
		else if(id >= 30 && id< 60)
		{
			return 1 % numReduceTasks;
		}
		else 		     
		{
			return 2 % numReduceTasks;
		}	

	}

}
