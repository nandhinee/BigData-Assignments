Description file for Assignment One
Submitted By: Nandhinee Neelakandan
UIN : 677734738

The project folder contains the following:
1. Driver class - Bfs.java
2. Mapper class - BfsMapper.java
3. Partitioner class - BfsPartitioner.java
4. Customised input format class - BfsInputFormat.java
5. Recoder Reader class	- BfsRecordReader.java
6. Reducer class - BfsReducer.java
7. Representation of nodes - Nodes.java
8. The input file nodes.txt which contains 56739 number of nodes with all the nodes colored white.

Steps for Running the program

1. Create a folder called input in the workspace and copy the file nodes.txt into it.
2. While running the program give three arguments in the command line
	1. input
	2. output
	3. source node
3. After running the program output files are created in the output directory with the last file having the shortest distance of each node from the source.
4. Another file called GraphStatistics.txt will be generated in the workspace that has the number of nodes and edges in the graph


