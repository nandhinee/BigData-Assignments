import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;


public class BfsReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	//The number of times the reducer has been invoked to find no. of nodes in the graph
	public static int mapredid;
	//count to maintain the number of nodes and edges
	public static int numberOfEdges;
	public static int totalIterations;
	@Override
	public void reduce(Text key, Iterator<Text> values,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		// A temp node for comparison
		Node node1 = new Node();
		node1.id=key.toString(); 
		while(values.hasNext()){
			//current node
			Node node2 = new Node(values.next().toString(), key.toString());
			
			//for not taking the empty spaces
			if(!node2.adjnodes.contains("")){
				node1.adjnodes=node2.adjnodes;
			}
			//to set the minimum distance of the node from the source and its parent 
			if (node2.dist<node1.dist){
				node1.dist=node2.dist;
				node1.parent=node2.parent;
			}
			//get the color of the temp node and the current node
			int colorid1=node1.color.ordinal();
			int colorid2=node2.color.ordinal();
			//set the darkest color to the node
			if(colorid1<colorid2)
				node1.color=node2.color;
		}
		
		//increment the no. of nodes and edges
		// number of mapredid and numberOfEdges are nodes*iterationCount and edges*iterationCount
		mapredid++;
		numberOfEdges+= node1.adjnodes.size();
		if (node1.getColor() == Node.colors.GRAY)
			Counter.cntr++;
		totalIterations = Counter.cntr;
		String str= new String();
		for(int i=0; i<node1.adjnodes.size(); i++){
			 str = str+node1.adjnodes.get(i)+",";		 
		}
		// to eliminate the "," in the last place
		if(str.charAt(str.length()-1)==',')
			 str = str.substring(0, str.length()-1);
		String ans = str+"|"+node1.dist+"|"+node1.color+"|"+node1.parent;
		// sends the key value pairs to the output file
		output.collect(key, new Text(ans));			
		}
	}

	

	


