import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.*;






public class Bfs extends Configured implements Tool{
	public static int srcNode;
	public static int jobcount;
	public static void main(String[] args) throws Exception {
		
		// srcNode contains the source node which is mentioned in the command line as 3rd argument
		// This is used for comparing the source with the key in the node.java class for the 1st iteration to set it's color from WHITE to GRAY
		srcNode = getarg(args);
		// res contains the total number of Iterations. Used for getting the graph statistics
		int res = ToolRunner.run(new Configuration(), new Bfs(), args);
        if(args.length != 3){
            System.err.println("Enter only three arguments");
        }
        // Find the number of nodes count and edges count by maintaining static variables in BfsReducer.java
        // mapredid and numberofEdges are declared as static variables in BfsReducer.java
        int nodesCount = BfsReducer.mapredid/res;
        int edgesCount = (BfsReducer.numberOfEdges/2)/res;
        // Write the statistics into a file
        File file = new File("GraphStatistcs.txt");
        if (!file.exists()) {
			file.createNewFile();
		}
        FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("Total number of nodes in the graph is "+nodesCount);
		bw.write("\nTotal number of edges in the graph is "+edgesCount);
		bw.close();
	}
	// returns the 3rd argument from the command line from all the command line arguments
	public static int getarg(String[] arg){
		return Integer.parseInt((arg[2]));
	}
		public int run(String[] args) throws Exception {
			int iterationCount = 0;
			while(Counter.cntr>0){
				//create a new job conf 
				JobClient client = new JobClient();
				JobConf conf = new JobConf(getConf(),Bfs.class);
				// set the job name
				conf.setJobName("BFS");
				//set the output data types for map-reduce job
				conf.setOutputKeyClass(Text.class);
				conf.setOutputValueClass(Text.class);
				conf.setJarByClass(Bfs.class);
				// set the customized input format class
				conf.setInputFormat(BfsInputFormat.class);
				// set the mapper class for the job conf
				conf.setMapperClass(BfsMapper.class);
				conf.setNumReduceTasks(3); 
				// set the partitioner class for the job conf
				conf.setPartitionerClass(BfsPartitioner.class);
				// set the reducer class for the job conf
				conf.setReducerClass(BfsReducer.class);
				String input, output;	
				// for the first iteration the input will be the first input argument
				 if (iterationCount == 0) 
		                input = args[0];
				 // from second iteration onwards the input file will be output+iterationCount
		            else
		                input = args[1] + iterationCount;
		 
		         output = args[1] + (iterationCount + 1);
		         iterationCount++;
		         jobcount = iterationCount;
		         // set the input and files	
		         FileInputFormat.setInputPaths(conf, new Path(input));	
				 FileOutputFormat.setOutputPath(conf, new Path(output)); 
				 client.setConf(conf);
				 JobClient.runJob(conf);
			}
			return iterationCount;      
		}

}

	

