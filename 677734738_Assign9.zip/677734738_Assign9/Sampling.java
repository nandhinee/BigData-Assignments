import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Sampling {
	public static void main(String args[]) {
		// read input and k value
		// k size of reservoir
		String input = args[0];
		int k = Integer.parseInt(args[1]);
		try {
			BufferedReader br2 = new BufferedReader(new FileReader(input));
			String line2;
			int n = 0;
			while ((line2 = br2.readLine()) != null) {
				n++;
			}
			// System.out.println(n);
			// create stream and reservior arrays
			if(k<1 || k>n){
				System.out.println("please give k between 1 and "+n );
			}
			int[] stream = new int[n];
			int[] reservoir = new int[k];
			FileReader fr = new FileReader(input);
			BufferedReader br = new BufferedReader(fr);
			String line;
			int size = 0;
			// read from the input and store it in the stream array
			while ((line = br.readLine()) != null) {
				stream[size] = Integer.parseInt(line);
				size++;
			}
			// place first k entries in reservoir
			for (int x = 0; x < k; x++) {
				reservoir[x] = stream[x];
				// System.out.println(reservoir[x]);
			}
			Random randomGenerator = new Random();
			for (int i = k + 1; i < stream.length; i++) {
				int j = randomGenerator.nextInt(i);
				if (j < k) {
					reservoir[j] = stream[i];
				}
			}
			FileWriter fw = new FileWriter("output.txt");
			for (int i = 0; i < reservoir.length; i++) {
				fw.append(reservoir[i] + "\n");
			}
			fw.close();
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
