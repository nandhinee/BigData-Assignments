Assignment Nine
Submitted by: Nandhinee Neelakandan
UIN : 677734738

The folder contains the following files:
1. Sampling.java - source file
2.input.txt - input file (with 10,000 random numbers)

Instructions to run the program
1. Place the input file in the workspace
2. When running the program give the following 2 arguments
	1.input.txt 
	2.number to sample(k)(e.g. 100)
3. output file will be generated in the workspace with k entries