Assignment Three
Submitted by: Nandhinee Neelakandan (677734738)

The folder contains the following files:

Source file:
Driver class - ItemBasedCF.java
Mapper class - ItemBasedCFMapper.java (for pass 1)
		ItemBasedCFMapper2.java(for pass 2)

Reducer class - ItemBasedCFReducer.java (for pass 1)
		ItemBasedCFReducer2.java (for pass 2)

Input format class - ItemBasedInputFormat.java (for pass 1)
		     ItemBasedInputFormat2.java(for pass 2)

Record Reader class - ItemBasedRecordReader.java (for processing the input for pass 1)
			ItemBasedRecordReader2.java (for processing the input for pass 2)

Representation of ratings - RatingStruct.java

Input file
data.txt - contains the set of all users and the movie ratings

Output file:
top_100.txt - contains top 100 movie pairs ordered by similarity score

Instructions to run the project:
1. Create a folder called input in the workspace and place the input file in there.
2. While running the project give two arguments in the command line 
	input 
	output
3. Three output files will be generated in the following folders:
	output1/part-00000 - output after 1st pass
	output2/part-00000 - output containing the movie pairs and their similarity score
	output2/top_100.txt - containing top 100 movies 

