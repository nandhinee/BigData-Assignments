import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;



public class ItemBasedCF extends Configured implements Tool {

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new ItemBasedCF(), args);
	}

	@Override
	public int run(String[] args) throws Exception {	
		// TODO Auto-generated method stub
		
		JobClient client = new JobClient();
		JobConf conf = new JobConf(getConf(),ItemBasedCF.class);
		// set the job name
		conf.setJobName("ItemBasedCF");
		//set the output data types for map-reduce job
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(Text.class);
		conf.setJarByClass(ItemBasedCF.class);
		// set the customized input format class
		conf.setInputFormat(ItemBasedInputFormat.class);
		// set the mapper class for the job conf
		conf.setMapperClass(ItemBasedCFMapper.class);
		// set the reducer class for the job conf
		conf.setReducerClass(ItemBasedCFReducer.class);
		String input, output;	
		input = args[0];
		output = args[1]+"1";
        // set the input and files	
        FileInputFormat.setInputPaths(conf, new Path(input));	
		FileOutputFormat.setOutputPath(conf, new Path(output)); 
		client.setConf(conf);
		JobClient.runJob(conf);
		
		//Second pass
		JobConf conf2 = new JobConf(getConf(),ItemBasedCF.class);
		// set the job name
		conf2.setJobName("ItemBasedCF2");
		//set the output data types for map-reduce job
		conf2.setOutputKeyClass(Text.class);
		conf2.setOutputValueClass(Text.class);
		conf2.setJarByClass(ItemBasedCF.class);
		// set the customized input format class
		conf2.setInputFormat(ItemBasedInputFormat2.class);
		// set the mapper class for the job conf
		conf2.setMapperClass(ItemBasedCFMapper2.class);
		// set the reducer class for the job conf
		conf2.setReducerClass(ItemBasedCFReducer2.class);
		String input2, output2;	
		input2 = "output1/part-00000";
		output2 = args[1]+"2";
	    // set the input and files	
	    FileInputFormat.setInputPaths(conf2, new Path(input2));	
	    FileOutputFormat.setOutputPath(conf2, new Path(output2)); 
		client.setConf(conf2);
		JobClient.runJob(conf2);
			
		BufferedReader reader = new BufferedReader(new FileReader("output2/part-00000"));
		FileWriter writer = new FileWriter("output2/top_100.txt");
	
		String line="";
		String[] str;
		// to remove the entries which are greater than the current 100 entries
        String remove = "";
        // to check if an entry in the hashmap should be removed
        boolean is_remove = false;
        // hash map to store only top 100 move pairs based on similarity score
        LinkedHashMap<String, Double> map_100 = new LinkedHashMap<String, Double>();
        	
        while ((line = reader.readLine()) != null) {
            str = line.split("\\t");
            String movie_pair= str[0].toString();
            double similarity_score = Double.parseDouble(str[1]);

            if (map_100.size() < 100) {
                map_100.put(movie_pair, similarity_score);              
            } 
            // if the current entry is greater than any of the entry in the hashtable, both keys and values will be replaced
            else {
                Set<String> hash_key = map_100.keySet();
                for (String keys : hash_key) {
                    if (similarity_score > map_100.get(keys)) {
                        remove = keys;
                        is_remove = true;
                        break;
                    }
                }
            }
            if (is_remove==true) {
                map_100.remove(remove);
                map_100.put(movie_pair, similarity_score);
                is_remove=false;
            }
        }
        reader.close();
        // top_100 contains only the top 100 rated movie pairs
        Set<String> hash_keys = map_100.keySet();
        for (String key : hash_keys) {
            writer.write(key + "\t" + map_100.get(key));
            writer.write("\n");
        }
        writer.close();
        return 0;
	}          
}
