import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;


public class ItemBasedCFReducer2 extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	public void reduce(WritableComparable _key, Iterator values,
			OutputCollector output, Reporter reporter) throws IOException {
		// replace KeyType with the real type of your key
		

			// process value
		}

	@Override 
	public void reduce(Text key, Iterator<Text> values,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		String str="";
		double nr =0, dr1=0, dr2= 0;
		double similarity;
		int size=0;
		// calculate cosine similarity for every movie pair
		while(values.hasNext()){
			String[] ratingstr = values.next().toString().split(",");
			double ratingx = Double.parseDouble(ratingstr[0]);
			double ratingy = Double.parseDouble(ratingstr[1]);
			nr = nr+(ratingx*ratingy);
			dr1 = dr1+(ratingx*ratingx);
			dr2 = dr2+(ratingy*ratingy);
			size++;
			
		}
		// the movie pairs which occur more than once are entered into the output file
		if(size>1){	
			similarity = nr/(Math.sqrt(dr1)*Math.sqrt(dr2));
			String ans = Double.toString(similarity);
			output.collect(key,new Text(ans));
		}
	}
}

