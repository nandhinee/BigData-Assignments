public class RatingStruct {

	String userid;
	String movieid;
	int rating;
	
	public RatingStruct(String input){
		String str = input.toString();
		// splits the input into movie and corresponding ratings
		//inputdata[0] contains movie id and inputdata[1] contains rating
		String[] inputdata = str.split("\\t");
		this.movieid=inputdata[0];
		this.rating=Integer.parseInt(inputdata[1]);
	}
}
