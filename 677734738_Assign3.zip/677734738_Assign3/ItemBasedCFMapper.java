import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;


public class ItemBasedCFMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

	public void map(WritableComparable key, Writable values,
			OutputCollector output, Reporter reporter) throws IOException {
	}

	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		RatingStruct struct1 = new RatingStruct(value.toString());
		
		struct1.userid = key.toString();	
		// creates an entry for user, movie and rating
		String id = struct1.userid;
		String values = struct1.movieid+"\t"+struct1.rating;
		output.collect(new Text(id), new Text(values));
		
	}
	
}
