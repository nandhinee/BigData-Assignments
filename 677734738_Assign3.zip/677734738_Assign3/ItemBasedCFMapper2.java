import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;


public class ItemBasedCFMapper2 extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

	public void map(WritableComparable key, Writable values,
			OutputCollector output, Reporter reporter) throws IOException {
	}

	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		String[] ratingpair = value.toString().split("\\t");
		int size = ratingpair.length;
		String[] movies= new String[size];
		String[] rating = new String[size];
		//  splitting movies and ratings
		for (int i =0; i< size; i++){
			String[] str1= ratingpair[i].split(",");
			movies[i]= str1[0];
			rating[i]= str1[1];
			
		}

		//to find the no. of pairs
		int no_of_pairs;
		no_of_pairs = (size*(size-1))/(1*2);
		String[] moviespair = new String[no_of_pairs];
		String[] ratingvalues = new String[no_of_pairs];
		//n keeps track of the array whose size will be equal to no_of_pairs
		int n=0;
		for(int i =0; i< size; i++){
			for(int j=i+1; j<size; j++){
				int comparison = movies[i].compareTo(movies[j]);
				if (comparison < 0){
					moviespair[n]=movies[i]+","+movies[j];
					ratingvalues[n]=rating[i]+","+rating[j];
				}
				else if (comparison > 0){
					moviespair[n]=movies[j]+","+movies[i];
				ratingvalues[n]=rating[j]+","+rating[i];
				}
				n++;
			}
		}
		
		for(int i=0; i<no_of_pairs; i++)
			output.collect(new Text(moviespair[i]), new Text(ratingvalues[i]));
		
	}
}
