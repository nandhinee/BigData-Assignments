public class DataPoints {
	String key;
	double[] points = new double[10];
	DataPoints(String points){
		String[] numberStrs = points.split(",");
		double[] numbers = new double[numberStrs.length];
		for(int i = 0;i < numberStrs.length;i++)
		{
		   numbers[i] = Double.parseDouble(numberStrs[i]);
		}
		for(int i=0;i<numbers.length;i++)
			this.points[i]=numbers[i];
	}
}
