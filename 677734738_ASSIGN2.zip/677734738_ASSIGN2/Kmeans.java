import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class Kmeans extends Configured implements Tool {
	
	public static int jobcount;
	static boolean completed = false;
	static int iterationCount = 0;
	// no_of_centroids is used to keep track of how many centroids are at a distances of <0.01 from it's previous
	public static int no_of_centroids = 0;
	//HashMap is used to store the centroids
	static HashMap<String, String> centroid_data = new HashMap<String, String>();
	public static void main(String[] args) throws Exception {
		
		int res = ToolRunner.run(new Configuration(), new Kmeans(), args);
	}

	@Override
	public int run(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		String input_path= args[0], output_path= args[1]; 
		String input_datafile="data_points.txt";
		String input, output;
		while(!completed){
			no_of_centroids = 0;
			JobClient client = new JobClient();
			JobConf conf = new JobConf(Kmeans.class);
			conf.setJobName("Kmeans");
			conf.setOutputKeyClass(Text.class);
			conf.setOutputValueClass(Text.class);
			conf.setJarByClass(Kmeans.class);
			// set the mapper class
			conf.setMapperClass(KmeansMapper.class);
			conf.setNumReduceTasks(3); 
			// set the partitioner class for the job conf
			conf.setPartitionerClass(KmeansPartitioner.class);
			// set the reducer class for the job conf
			conf.setReducerClass(KmeansReducer.class);
			// iterationCount is used to set the centroids during the first iteration in a HashMap
			input = input_path+"/"+input_datafile;
		    output = output_path + (iterationCount + 1);
		    iterationCount++;
	        jobcount = iterationCount;
		         
		    // set the input and files	
		    FileInputFormat.setInputPaths(conf, new Path(input));	
		    FileOutputFormat.setOutputPath(conf, new Path(output)); 
		    client.setConf(conf);
		    JobClient.runJob(conf);
		} //end of while	
		return 0;
	}

}