import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Partitioner;


public class KmeansPartitioner extends MapReduceBase implements Partitioner<Text,Text> {

	@Override
	public int getPartition(Text key, Text value, int numReduceTasks) {
		// TODO Auto-generated method stub
		int id= Integer.parseInt(key.toString().substring(1,
				key.toString().length()));	
		
		// to avoid mod by 0
		if(numReduceTasks == 0)
			return 0;
		
		
		if ( id<=500)
		{
			return 0;
		}
		else if(id >= 501 && id< 700)
		{
			return 1 % numReduceTasks;
		}
		else 		     
		{
			return 2 % numReduceTasks;
		}	

	}

}
