import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;


public class KmeansMapper extends MapReduceBase implements Mapper <LongWritable, Text, Text, Text>  {
	static String[] columns;
	// k is used to find the number of clusters
	public static int k=0;
	public void map(WritableComparable key, Writable values,
			OutputCollector output, Reporter reporter) throws IOException {
	}

	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		String c_id, c_points;
		
		if(Kmeans.jobcount==1){
			// to store the initial centroids in a HashMap
			Scanner scanner = new Scanner(new FileReader("input/centroid.txt"));
	        while (scanner.hasNextLine()) {
	            columns = scanner.nextLine().split("\t");
	            Kmeans.centroid_data.put(columns[0], columns[1]);
	            k++;
	        }
	        Kmeans.jobcount++;        
		}
		
		// split the input value
		String[] str = value.toString().split("\t");
		DataPoints d1 = new DataPoints(str[1]);
		d1.key=str[0];
		Set mapSet = (Set) Kmeans.centroid_data.entrySet();
        Iterator mapIterator = mapSet.iterator();
        double prev_dist=Long.MAX_VALUE;
        //current distance
        double distance;
        // to find the distance between the point from all the centroids
        while (mapIterator.hasNext()) {
        	double sum = 0 ;
        	Map.Entry mapEntry = (Map.Entry) mapIterator.next();
        	c_id = (String) mapEntry.getKey();
        	c_points = (String) mapEntry.getValue();
        	String[] numberStrs = c_points.split(",");
    		double[] numbers = new double[numberStrs.length];
    		for(int i = 0;i < numberStrs.length;i++){
    		   numbers[i] = Double.parseDouble(numberStrs[i]);   
    		}
    		// for summing up all the differences until 10th point
    		for(int i =0; i<10;i++){
    			sum = sum+((d1.points[i]-numbers[i])*(d1.points[i]-numbers[i]));
    		}
    		// distance between the point and the centroid
    		distance = Math.sqrt(sum);
    		
    		//to take the minimum distance of the point from all the centroids
    		if(distance<prev_dist){
    			d1.key=c_id;
    			prev_dist=distance;
    		}		
        }//end of while
		String datapoints= str[1];	
		output.collect(new Text(d1.key), new Text(datapoints));
	}
	
	
}
