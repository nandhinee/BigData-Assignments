import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;


public class KmeansReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {
	
	public void reduce(WritableComparable _key, Iterator values,
			OutputCollector output, Reporter reporter) throws IOException {
		// replace KeyType with the real type of your key

		}

	@Override
	public void reduce(Text key, Iterator<Text> value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		double count = 0;
		double[] total = new double[10];
		for(int i=0;i<10;i++)
			total[i]=0;
		// to find the count of data points for a single cluster
		while (value.hasNext()) {
			String data_str= value.next().toString();
			DataPoints d1 = new DataPoints(data_str);
			for(int i=0;i<10;i++)
				total[i]=total[i]+d1.points[i];
			count++;		
		}
		double[] points_new = new double[10];
		String data_new="";
		for(int i = 0; i<10; i++)
			points_new[i]=total[i]/count;
		for(int i = 0; i<10; i++){
			data_new=data_new+","+String.valueOf(points_new[i]);
		}
		// mid point of all the points for that centroid id
		data_new=data_new.substring(1, data_new.length());
		// d2 is current new point
		DataPoints d2 = new DataPoints(data_new);
		
		//creating a node for the centroid
		DataPoints d3 = new DataPoints(Kmeans.centroid_data.get(key.toString()));
		// to calculate the distance between the new centroid point and the old centroid point
		double temp_sum = 0;
		double dist_centroid;
		for(int i =0; i<10;i++){
			temp_sum = temp_sum+((d2.points[i]-d3.points[i])*(d2.points[i]-d3.points[i]));
		}
		dist_centroid = Math.sqrt(temp_sum);
		// only when every new centroid is at a distance of < 0.01 the job is completed
		if(dist_centroid<0.01){
			Kmeans.no_of_centroids++; 
			if(Kmeans.no_of_centroids == KmeansMapper.k){
				Kmeans.completed=true;
			}	
			else 
				Kmeans.centroid_data.replace(key.toString(), data_new);
				output.collect(key, new Text(data_new));
		}
		else{
			Kmeans.centroid_data.replace(key.toString(), data_new);
			output.collect(key, new Text(data_new));
			
		}
		 	
	}
}

