Assignment Two
Submitted by : Nandhinee Neelakandan (677734738)

The folder consists of the following:

Source file:
Driver class - Kmeans.java
Mapper class - KmeansMapper.java
Reducer class - KmeansReducer.java
Partitioner class - KmeansPartitioner.java
Representation of data points - DataPoints.java

Input files
data_points.txt - contains the set of all data points for which we need to find the centroids
centroid.txt - initial set of centroids (the number of centroids determine how many k clusters should be formed)

Instructions to run the project:
1. Create a folder called input in the workspace and place the two input files in there.
2. While running the project give two arguments in the command line 
	input 
	output
3. A certain number of output files will be generated with the last file containing the final centroid points around which the corresponding clusters are formed.
