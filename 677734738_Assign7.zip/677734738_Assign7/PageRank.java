import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class PageRank extends Configured implements Tool {

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new PageRank(), args);
	}

	@Override
	public int run(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int iteration_count = 0;
		boolean completed = false;
		while (!completed) {
			JobClient client = new JobClient();
			JobConf conf = new JobConf(getConf(), PageRank.class);
			// set the job name
			conf.setJobName("PageRank");
			// set the output data types for map-reduce job
			conf.setOutputKeyClass(Text.class);
			conf.setOutputValueClass(Text.class);
			conf.setJarByClass(PageRank.class);
			// set the mapper class for the job conf
			conf.setMapperClass(PageRankMapper.class);
			// set the reducer class for the job conf
			conf.setReducerClass(PageRankReducer.class);
			String input, output;
			if (iteration_count == 0)
				input = args[0];
			else
				input = args[1] + iteration_count;

			output = args[1] + (iteration_count + 1);
			iteration_count++;
			// set the input and files
			FileInputFormat.setInputPaths(conf, new Path(input));
			FileOutputFormat.setOutputPath(conf, new Path(output));

			client.setConf(conf);
			JobClient.runJob(conf);
			// to set the stopping criteria
						if (iteration_count > 1) {
							FileReader fr1 = new FileReader(args[1] + (iteration_count - 1)+"/part-00000");
							FileReader fr2 = new FileReader(args[1] + iteration_count+"/part-00000");
							BufferedReader br1 = new BufferedReader(fr1);
							BufferedReader br2 = new BufferedReader(fr2);
							String s1, s2;
							double[] rank1 = new double[100];
							double[] rank2 = new double[100];
							int x = 0, y = 0;
							while ((s1 = br1.readLine()) != null) {
								String[] line1 = s1.split("\\t");
								String[] r1 = line1[0].split(",");
								rank1[x] = Double.parseDouble(r1[1]);
								x++;
							}
							while ((s2 = br2.readLine()) != null) {
								String[] line2 = s2.split("\\t");
								String[] r2 = line2[0].split(",");
								rank2[y] = Double.parseDouble(r2[1]);
								y++;
							}
							int c = 0;
							for (int i = 0; i < 100; i++) {

								if ((rank1[i] - rank2[i] < 0.05))
									c++;
							}
							//if all nodes have rank difference <0.05
							if (c == 100)
								completed = true;

						}

		}
		return 0;

	}
}
