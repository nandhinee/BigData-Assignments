
public class RankStruct {
	String page_id;
	 double rank;
	 String adjlist;
 
public RankStruct(String input) {
	// TODO Auto-generated constructor stub
	//str1[0]-> pg,rank; str1[1]-> adj list
	 String[] str1 = input.split("\\t");
	 // spiltting pg, rank into a var for pg and rank
	 String[] str=str1[0].split(",");
	 //str[0]->pg ; str[1]->rank
	 this.page_id=str[0];
	 this.rank=Double.parseDouble(str[1]);
	 
	 // adjlist->str1[1]; to be split in mapper
	
	 if(str1.length>1){
		 this.adjlist=str1[1];
		
	 }
	 else this.adjlist="empty";
	 
}
}
