Assignment Seven
Submitted by: Nandhinee Neelakandan
UIN: 677734738

The folder consists of the following files:

PageRank.java - Driver Class
PageRankMapper.java - Mapper Class
PageRankReducer.java -Reducer Class
RankStruct.java - Contains the code to format the rank

Input file: input 

To run the program:
1. Create a folder called input in the workspace and place the input file
2. While running the program give the following parameters in the command line
	input output
3. During each iteration to check the stopping criteria, part-00000 file of current iteration is compared with part-00000 file of previous iteration.
4. A set of output files will be created in the workspace with the page ranks corresponding to rank during each iteration when the stopping critera is satisfied.
