import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;


public class PageRankReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {

	

	@Override
	public void reduce(Text key, Iterator<Text> values,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		String str="";
		String v_temp = values.toString();
		double rank=0;
		int n=0;
		String temp="";
		while(values.hasNext()){
			String val = values.next().toString();
			if(!val.contains("->")){
				//val_rank[0] contains parent pg and val_rank[1] contains key's rank
				String[] val_rank=val.split(",");
				double curr_rank = Double.parseDouble(val_rank[1]);
				
				rank=rank+(curr_rank*0.8);
				
			}
			else{
				temp=val.replace("->", "");
				String[] adj_nodes=temp.split(",");
				n=adj_nodes.length;
				
			}
			 
		}
		
		rank=rank+(0.2/100);
		
		String rank_str= Double.toString(rank);
		output.collect(new Text(key+","+rank_str),new Text(temp));
	}

}