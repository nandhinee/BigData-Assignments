import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class PageRankMapper extends MapReduceBase implements
		Mapper<LongWritable, Text, Text, Text> {

	public void map(WritableComparable key, Writable values,
			OutputCollector output, Reporter reporter) throws IOException {
	}

	@Override
	public void map(LongWritable key, Text value,
			OutputCollector<Text, Text> output, Reporter r) throws IOException {
		// TODO Auto-generated method stub
		
		String input = value.toString();
		String[] adj_pages;
		RankStruct rs = new RankStruct(input);
		// process nodes with outlinks
		if(!rs.adjlist.equals("empty")){
			adj_pages = rs.adjlist.split(",");
			int no_of_adj_pg = adj_pages.length;
			String adj_pg_no, src_pg, str2;
			double rank;
			for (int i = 0; i < adj_pages.length; i++) {
				adj_pg_no = adj_pages[i];
				src_pg = rs.page_id;
				rank = rs.rank/adj_pages.length;
				str2 = src_pg + "," + rank;
				output.collect(new Text(adj_pg_no.toString()), new Text(str2));
			}
			
		}
		
		output.collect(new Text(rs.page_id), new Text("->"+rs.adjlist));	
	}
}