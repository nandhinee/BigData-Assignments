import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class topicModel {

	public static void main(String args[]) throws FileNotFoundException {

		// to process the vocab file and store the words with their id in a
		// hashmap
		BufferedReader reader_vocab = new BufferedReader(new FileReader(
				"vocab.txt"));
		LinkedHashMap<Integer, String> map = new LinkedHashMap();
		int word_id = 0;
		String line = "";
		try {
			while ((line = reader_vocab.readLine()) != null) {
				word_id++;
				map.put(word_id, line);

			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// to read the lines in docword and write the contents of each word
		// doucument
		BufferedReader reader_docword = new BufferedReader(new FileReader(
				"docword.nips.txt"));
		int no_of_lines = 0;
		String doc_line = "";
		String[] str;
		String prev_docid = "1";
		String curr_docid = "";
		int no_of_docs = 0;
		String content = "";
		int no_of_occurances = 0;
		int wordid = 0;
		try {
			while ((doc_line = reader_docword.readLine()) != null) {
				no_of_lines++;

				if (no_of_lines > 3) {
					str = doc_line.split(" ");
					curr_docid = str[0];
					wordid = Integer.parseInt(str[1]);
					no_of_occurances = Integer.parseInt(str[2]);
					// Writes to string only if curr = prev
					if (curr_docid.equalsIgnoreCase(prev_docid)) {
						for (int i = 0; i < no_of_occurances; i++) {
							content += map.get(wordid) + " ";
						}
					}

					if (!curr_docid.equals(prev_docid)) {
						// path
						FileWriter fwriter = new FileWriter("output/"
								+ prev_docid + ".txt");
						// write statement
						fwriter.write(content);
						// clear
						content = "";
						fwriter.close();

						// append the words to a string
						for (int i = 0; i < no_of_occurances; i++) {
							content += map.get(wordid) + " ";
						}
						no_of_docs++;
					}
					prev_docid = str[0];
				}

			}
			FileWriter fwriter = new FileWriter("output/" + prev_docid + ".txt");
			no_of_docs++;
			fwriter.write(content);
			fwriter.close();
			System.out.println("no_of_docs" + no_of_docs);// end of while

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
