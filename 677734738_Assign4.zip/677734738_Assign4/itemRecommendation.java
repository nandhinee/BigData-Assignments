package itembasedRS.itembasedRS;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.recommender.ItemBasedRecommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;

public class itemRecommendation {
     
      public static void main(String args[])
      {
            try
            {
                  //File Data model created to accept the input file(userid, itemid, rating)
                  FileDataModel dataModel = new FileDataModel(new File("data.txt"));
                 
                  // calculate Pearson Similarity
                  ItemSimilarity itemSimilarity = new PearsonCorrelationSimilarity(dataModel);
                 
                  
                  ItemBasedRecommender recommender =new GenericItemBasedRecommender(dataModel, itemSimilarity);
                 
                  /*calling the recommend method to generate recommendations with userid, no of item recommendations as parameters*/
                  List<RecommendedItem> recommendations =recommender.recommend(100,10);
           
                  for (RecommendedItem recommendedItem : recommendations)
                        System.out.println(recommendedItem.getItemID());
            }
            catch (IOException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
            } catch (TasteException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
            }
           
      }
}