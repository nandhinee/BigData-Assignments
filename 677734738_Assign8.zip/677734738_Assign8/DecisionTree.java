import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class DecisionTree {
	static int node_no=0;
	static double max_pure;
	public static void main(String args[]) {
		// read the file and store it in a 2D array
		String input = args[0];
		int day = 0, attr = 0;
		try {
			FileReader fr2 = new FileReader(input);
			BufferedReader br2 = new BufferedReader(fr2);
			String in;
			// to get no of days and attributes
			while ((in = br2.readLine()) != null) {
				String attributes[] = in.split("\t");
				day++;
				attr = attributes.length;
			}

			String[][] datapoints = new String[day][attr];

			FileReader fr = new FileReader(input);
			BufferedReader br = new BufferedReader(fr);
			String line;
			int line_no = 0;
			// store data points in the array
			while ((line = br.readLine()) != null) {
				String d_pts[] = line.split("\t");
				for (int i = 0; i < d_pts.length; i++) {
					datapoints[line_no][i] = d_pts[i];
				}
				line_no++;
			}
			// calculate entropy for all cases:
			double n_pos = 0, n_neg = 0, n_tot = day;
			for (int i = 0; i < day; i++) {
				if (datapoints[i][attr - 1].equalsIgnoreCase("yes")) {
					n_pos++;
				} else
					n_neg++;
			}
			//System.out.println(n_pos + "\t" + n_neg + "\t" + n_tot);
			// H(S) formula
			double h_s;
			double pos_ratio, neg_ratio;
			pos_ratio = n_pos / n_tot;
			neg_ratio = n_neg / n_tot;
			h_s = CalEntropy(pos_ratio, neg_ratio);
			
			// find root split
			
			 List<Double> ar=new ArrayList<Double>();// to find the maximum info gain
			for (int j = 0; j < attr - 1; j++) {
				List<String> attributes_list = new ArrayList<String>();
				HashMap<Double,LinkedHashSet> temp_map= new HashMap<Double,LinkedHashSet>();
				for (int i = 0; i < day; i++) {
					// find no_of categories
					attributes_list.add(datapoints[i][j]);
				}// list for all days
					// find only unique categories
				LinkedHashSet<String> uniqueAttr = new LinkedHashSet<String>(
						attributes_list);
				Iterator itr = uniqueAttr.iterator();
				String attr_to_process;
				double h_attr = 0;
				// 2nd part in information gain H(s)-sum_ratio =gain
				double info_gain=h_s;
				while (itr.hasNext()) {
					attr_to_process = (String) itr.next();
					// these variables keep track of no of pos and negative for
					// to_process_attr
					double pos_attr = 0, neg_attr = 0;
					double tot_attr;
					for (int i = 0; i < day; i++) {
						if (datapoints[i][j].equalsIgnoreCase(attr_to_process)) {
							if (datapoints[i][attr - 1].equalsIgnoreCase("yes")) {
								pos_attr++;
							} else
								neg_attr++;
						}
					}
					tot_attr = pos_attr + neg_attr;
					//System.out.println(pos_attr + "\t" + neg_attr);
					// calculate entropy
					
					double p_ratio, n_ratio;
					p_ratio = pos_attr / tot_attr;
					n_ratio = neg_attr / tot_attr;
					h_attr = CalEntropy(p_ratio, n_ratio);
					//System.out.println("attribute entropy "+h_attr);
					info_gain=info_gain-((tot_attr/n_tot)*h_attr);
				}//end of inner for
				
				ar.add(info_gain);
				// to store the attribute value with its uniqu values in a hashmap
				
				// }
			}// end of 1st for
			
			 double max=Collections.max(ar);
			 int gain_attr=ar.indexOf(max); 
			 //System.out.println(gain_attr);
			 FileWriter temp = new FileWriter("temp.txt");
			 List<String> temp_attributes_list = new ArrayList<String>();
			 
			 for(int j=0;j<attr;j++){
				 if(j==gain_attr){
					 for (int i = 0; i < day; i++) {
							// find no_of categories
							temp_attributes_list.add(datapoints[i][j]);
						}
				 }
			 }
			 LinkedHashSet<String> temp_uniqueAttr = new LinkedHashSet<String>(
					 temp_attributes_list);
			 Iterator temp_itr= temp_uniqueAttr.iterator();
			 String attr_val;
			 
			 while(temp_itr.hasNext()){
				 attr_val=(String) temp_itr.next();
				 node_no++;
				 List <String> ans = new ArrayList<String>();
				 for(int d=0;d<day;d++){
					 if(datapoints[d][gain_attr].equalsIgnoreCase(attr_val)){
						 ans.add(datapoints[d][attr-1]);
					 }
				 }
				 LinkedHashSet<String> is_stop = new LinkedHashSet<String>(
						 ans);
				 if(is_stop.size()==1){
					 temp.write("0->"+node_no+"\t"+gain_attr+","+attr_val+"\t"+is_stop.toString()+"\tstop");
					 temp.write("\n");
				 }
				 else{
					 temp.write("0->"+node_no+"\t"+gain_attr+","+attr_val+"\tcontinue");
					 temp.write("\n");
				 }
			 }
			
			 temp.close();
			 //root node has been found and child nodes for it are written into the file
			 FileReader fw_rec = new FileReader("temp.txt");
			 BufferedReader bw_rec = new BufferedReader(fw_rec);
			 String l;
			 while((l=bw_rec.readLine())!=null){
				 //check[0] 0->1; check[1] /0,sunny/; check[2] continue
				 String[] check=l.split("\t");
				 int len=check.length;
				 if(check[len-1].equalsIgnoreCase("continue")){
					 String str=check[0];
					 String str2= check[1];
					 if(check[1].contains("|")){
						 String s[]=check[1].split("|");
						 String prev_attr[]=s[s.length-1].split(",");
						 int size=0;
						 FileReader fr4 = new FileReader(input);
							BufferedReader br4 = new BufferedReader(fr4);
							String line4;
							while ((line4 = br4.readLine()) != null) {
								if(line4.contains(prev_attr[1])){
									size++;
								}
							}
								String[][] datapoints3= new String[size][attr];
						 FileReader fr3 = new FileReader(input);
							BufferedReader br3 = new BufferedReader(fr3);
							String line3;
							int line_no3 = 0;
							// store data points in the array
							while ((line3 = br3.readLine()) != null) {
							if(line3.contains(prev_attr[1])){
								String d_pts[] = line3.split("\t");
								for (int i = 0; i < d_pts.length; i++) {
									datapoints3[line_no3][i] = d_pts[i];
								}
								line_no3++;
								}
							}
							
						 int max_gain2= CalInfoGain(prev_attr,attr, size, datapoints3);
						 //System.out.println("max gain for the subtrees "+max_gain2);
						 WriteFile(attr, max_gain2,size,datapoints3,check[0],check[1],check[2]);
						 
					 }else{
						 //prev_attr[0]=attribute with max info gain prev_attr[1]=attributes
						 String prev_attr[]=check[1].split(",");
						 int size=0;
						 FileReader fr4 = new FileReader(input);
							BufferedReader br4 = new BufferedReader(fr4);
							String line4;
							while ((line4 = br4.readLine()) != null) {
								if(line4.contains(prev_attr[1])){
									size++;
								}
							}
								String[][] datapoints3= new String[size][attr];
						 FileReader fr3 = new FileReader(input);
							BufferedReader br3 = new BufferedReader(fr3);
							String line3;
							int line_no3 = 0;
							// store data points in the array
							while ((line3 = br3.readLine()) != null) {
							if(line3.contains(prev_attr[1])){
								String d_pts[] = line3.split("\t");
								for (int i = 0; i < d_pts.length; i++) {
									datapoints3[line_no3][i] = d_pts[i];
								}
								line_no3++;
								}
							}
							
						 int max_gain2= CalInfoGain(prev_attr,attr, size, datapoints3);
						 //System.out.println("max gain for the subtrees "+max_gain2);
						 WriteFile(attr, max_gain2,size,datapoints3,check[0],check[1],check[2]);
						  }
					 }//else if(check[len-1].equalsIgnoreCase("stop")){
						// WriteFile(l);
					 //}
					 
				 }
			 System.out.println("purity of the tree in percentage is "+max_pure*100);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		}
	public static void WriteFile(String l){
		try {
			FileWriter temp3 = new FileWriter("temp.txt", true);
			temp3.write(l);
			temp3.write("\n");
			temp3.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static double CalEntropy(double positive_ratio, double negative_ratio) {
		double entropy;
		if (positive_ratio == 0 || negative_ratio == 0) {
			return 0;
		} else {
			entropy = -(positive_ratio)
					* (Math.log(positive_ratio) / Math.log(2))
					- (negative_ratio)
					* (Math.log(negative_ratio) / Math.log(2));
			return entropy;
		}
	}
	public static int CalInfoGain(String[] to_avoid, int attr, int day, String[][] datapoints2){
	//System.out.println(to_avoid[0]);
		
	List<Double> ar=new ArrayList<Double>();
	List<Double> pr=new ArrayList<Double>();// to find the maximum info gain
	for (int j = 0; j < attr - 1; j++) {
		if(j!=Integer.parseInt(to_avoid[0])){
			double n_pos = 0, n_neg = 0, n_tot;
			for (int i = 0; i < day; i++) {
				if (datapoints2[i][attr - 1].equalsIgnoreCase("yes")) {
					n_pos++;
				} else if(datapoints2[i][attr - 1].equalsIgnoreCase("no"))
					n_neg++;
			}
			//System.out.println(n_pos + "\t" + n_neg + "\t" + n_tot);
			// H(S) formula
			double h_s;
			
			double pos_ratio, neg_ratio;
			n_tot=n_pos+n_neg;
			pos_ratio = n_pos / n_tot;
			neg_ratio = n_neg / n_tot;
			h_s = CalEntropy(pos_ratio, neg_ratio);
			//System.out.println("h(s)"+h_s + "\t" +"posratio"+pos_ratio + "\t" +"negratio"+ neg_ratio);
			
		List<String> attributes_list = new ArrayList<String>();
		HashMap<Double,LinkedHashSet> temp_map= new HashMap<Double,LinkedHashSet>();
		for (int i = 0; i < day; i++) {
			// find no_of categories
			attributes_list.add(datapoints2[i][j]);
		}// list for all days
			// find only unique categories
		LinkedHashSet<String> uniqueAttr = new LinkedHashSet<String>(
				attributes_list);
		//System.out.println(uniqueAttr);
		Iterator itr = uniqueAttr.iterator();
		String attr_to_process;
		double h_attr = 0;
		// 2nd part in information gain H(s)-sum_ratio =gain
		double info_gain=h_s;
		while (itr.hasNext()) {
			attr_to_process = (String) itr.next();
			// these variables keep track of no of pos and negative for
			// to_process_attr
			double pos_attr = 0, neg_attr = 0;
			double tot_attr;
			for (int i = 0; i < day; i++) {
				if (datapoints2[i][j].equalsIgnoreCase(attr_to_process)) {
					if (datapoints2[i][attr - 1].equalsIgnoreCase("yes")) {
						pos_attr++;
					} else
						neg_attr++;
				}
			}
			tot_attr = pos_attr + neg_attr;
			
			// calculate entropy
			
			double p_ratio, n_ratio;
			p_ratio = pos_attr / tot_attr;
			n_ratio = neg_attr / tot_attr;
			h_attr = CalEntropy(p_ratio, n_ratio);
			//information gain
			info_gain=info_gain-((tot_attr/n_tot)*h_attr);
			// to calculate purity
			double purity;
			if( pos_attr > neg_attr){
				purity=pos_attr/tot_attr;
			}
			else
				purity=neg_attr/tot_attr;
			pr.add(purity);
		}//end of inner for
		//System.out.println("is this info gain"+info_gain);
		ar.add(info_gain);
		
		
		}
		if(j==Integer.parseInt(to_avoid[0])){
			ar.add(0.0);
		
		}
	}// end of 1st for
	
	 double max=Collections.max(ar);
	 max_pure=Collections.max(pr);
	 //System.out.println("purity of this subtree is"+ max_pure*100);
	 int gain_attr=ar.indexOf(max); 
	
		return gain_attr;
	
		}
		public static void WriteFile( int attr, int gain_attr, int day,String datapoints[][], String col1, String col2, String col3){
			try{
			 FileWriter temp2 = new FileWriter("temp.txt", true);
			 List<String> temp_attributes_list = new ArrayList<String>();
			 
			 for(int j=0;j<attr;j++){
				 if(j==gain_attr){
					 for (int i = 0; i < day; i++) {
							// find no_of categories
							temp_attributes_list.add(datapoints[i][j]);
						}
				 }
			 }
			 LinkedHashSet<String> temp_uniqueAttr = new LinkedHashSet<String>(
					 temp_attributes_list);
			 Iterator temp_itr= temp_uniqueAttr.iterator();
			 String attr_val;
			 
			 while(temp_itr.hasNext()){
				 attr_val=(String) temp_itr.next();
				 node_no++;
				 List <String> ans = new ArrayList<String>();
				 for(int d=0;d<day;d++){
					 if(datapoints[d][gain_attr].equalsIgnoreCase(attr_val)){
						 ans.add(datapoints[d][attr-1]);
					 }
				 }
				 LinkedHashSet<String> is_stop = new LinkedHashSet<String>(
						 ans);
				 StringBuilder sb;
				 if(is_stop.size()==1){
					 //System.out.println(col1);
					 String str1=col1+"->"+node_no;
					 String str2=col2+"|"+gain_attr+","+attr_val;
					 String str4 = "stop";
					 String str3 = is_stop.toString();
					 temp2.flush();
					 temp2.write(str1+"\t"+str2+"\t"+str3+"\t"+str4);
					 temp2.write("\n");
				 }
				 else{
					 String str1=col1+"->"+node_no;
					 String str2=col2+"|"+gain_attr+","+attr_val;
					 String str3 = "continue";
					 temp2.flush();
					 temp2.write(str1+"\t"+str2+"\t"+str3);
					 temp2.write("\n");
				 }
			 }
			
			 temp2.close();
			}catch(IOException e){
				e.printStackTrace();
			}
			
		}
	
}// end of class
