import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class SignatureMatrix {
	// signature matrix 
	public void CreateMatrix(String doc_name) {
		try {
			BufferedReader br1 = new BufferedReader((new FileReader(
					"shingles.txt")));
			// store the shingles in 2D array[shingle_id][doc_id] from the file
			int[][] shingle_matrix = new int[SimilarDocuments.no_of_shingles][SimilarDocuments.no_of_docs];

			int rows1 = 0;
			String line1;
			String[] shingles;
			while ((line1 = br1.readLine()) != null) {
				shingles = line1.split("\t");
				for (int col = 0; col < shingles.length; col++) {
					int column = Integer.parseInt(shingles[col]);
					shingle_matrix[rows1][col] = column;
				}
				rows1++;
			}
			// to store the hash values in an array from the file
			BufferedReader br2 = new BufferedReader(new FileReader("hash.txt"));
			int[][] hash_matrix = new int[SimilarDocuments.no_of_shingles][SimilarDocuments.no_of_hash];
			int rows2 = 0;
			String line2;
			String[] hashVal;
			while ((line2 = br2.readLine()) != null) {
				hashVal = line2.split("\t");
				for (int col = 0; col < hashVal.length; col++) {
					int column = Integer.parseInt(hashVal[col]);
					hash_matrix[rows2][col] = column;
				}
				rows2++;
			}
			// create the signature matrix hash_num X no of docs
			int[][] signatureMatrix = new int[SimilarDocuments.no_of_hash][SimilarDocuments.no_of_docs];
			for (int k = 0; k < SimilarDocuments.no_of_hash; k++) {
				for (int j = 0; j < SimilarDocuments.no_of_docs; j++) {
					int temp = SimilarDocuments.no_of_shingles - 1;
					for (int i = 0; i < SimilarDocuments.no_of_shingles; i++) {

						if (shingle_matrix[i][j] == 1) {
							if (hash_matrix[i][k] < temp) {
								temp = hash_matrix[i][k];
							}
						}
					}
					signatureMatrix[k][j] = temp;
				}
			}
			// write the signature matrix into a file
			FileWriter fw = new FileWriter(doc_name);
			for (int i = 0; i < SimilarDocuments.no_of_hash; i++) {
				for (int j = 0; j < SimilarDocuments.no_of_docs; j++) {
					fw.write(signatureMatrix[i][j] + "\t");
				}
				fw.write("\n");
			}
			fw.close();
			String[] bucket = new String[SimilarDocuments.no_of_buckets];
			for (int i = 0; i < bucket.length; i++) {
				bucket[i] = "";
			}
			// inserting documents into corresponding buckets using % 
			for (int c = 0; c < SimilarDocuments.no_of_docs; c++) {
				int sum = 0;
				String doc_no = Integer.toString(c + 1);
				for (int r = 0; r < SimilarDocuments.no_of_hash; r++) {
					sum = sum + signatureMatrix[r][c];
					if ((r + 1) % SimilarDocuments.no_of_bands == 0) {
						int index = sum % SimilarDocuments.no_of_buckets;
						sum = 0;
						for (int i = 0; i < SimilarDocuments.no_of_buckets; i++) {
							if (i == index) {
								if (bucket[i].equals("")) {
									bucket[i] = doc_no;
								} else {
									bucket[i] = bucket[i] + "," + doc_no;
								}
							}
						}
					}
				}
			}
			// print the documents from bucket into a file
			FileWriter bucket_file = new FileWriter("buckets.txt");
			for (int i = 0; i < SimilarDocuments.no_of_buckets; i++) {
				bucket_file.write(i + "->" + bucket[i]);
				bucket_file.write("\n");
			}
			bucket_file.close();
			// to find similar documents and storing it as a set
			Set<String> sim = new HashSet<String>();
			for (int i = 0; i < bucket.length; i++) {
				String[] docs = bucket[i].split(",");
				for (int j = 0; j < docs.length; j++) {
					for (int k = j + 1; k < docs.length; k++) {
						if (!docs[j].equals(docs[k])) {
							sim.add("(" + docs[j] + "," + docs[k] + ")");
						}
					}
				}

			}
			String line = "";
			Iterator itr = sim.iterator();
			FileWriter output = new FileWriter("SimilarDocuments.txt");
			while (itr.hasNext()) {
				line = (String) itr.next();
				output.write(line);
				output.write("\n");
			}
			output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
