import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;


public class DocumentShingles {
	public DocumentShingles(String doc_name){
		try {
			FileWriter fw = new FileWriter(doc_name);
			Random randomGenerator = new Random();
			for(int i =0; i<SimilarDocuments.no_of_shingles;i++){
				for (int j=0;j<SimilarDocuments.no_of_docs;j++){
					//genarates 0,1
					int randomInt = randomGenerator.nextInt(2);
					fw.append(randomInt+"\t");				
				}
				fw.append("\n");	
			}
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
