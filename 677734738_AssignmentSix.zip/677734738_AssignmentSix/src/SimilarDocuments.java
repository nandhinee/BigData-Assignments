
public class SimilarDocuments {
	
	public static int no_of_docs=50;
	public static int no_of_shingles=100;
	public static int no_of_hash=8;
	public static int no_of_buckets=40;
	public static int no_of_bands=4;
	
	public static void main(String args[]){
		//create input files
		// shingles.txt contains the shingles for every documents
		DocumentShingles ds = new DocumentShingles("shingles.txt");
		// contains the set of values to which the shingles have to be hashed
		HashDocument ad = new HashDocument("hash.txt");
		SignatureMatrix sign = new SignatureMatrix();
		
		// 1. creates a file called SignatureMatrix that contains signatures of every document
		// 2. creates a file for the buckets containing the documents in them
		// 3. creates a file that contains all pairs of similar documents
		sign.CreateMatrix("SignatureMatrix.txt");
	}
}
