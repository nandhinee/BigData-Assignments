import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class HashDocument {
	public HashDocument(String doc_name) {
		try {
			FileWriter fw = new FileWriter(doc_name);
			Random randomGenerator = new Random();
			int[][] random_hash = new int[SimilarDocuments.no_of_shingles][SimilarDocuments.no_of_hash];

			ArrayList<Integer> numbers = new ArrayList<Integer>();
			for (int i = 0; i < SimilarDocuments.no_of_shingles; i++) {
				numbers.add(i + 1);
			}
			for(int c=0;c<SimilarDocuments.no_of_hash;c++){
				Collections.shuffle(numbers);
				for(int r=0;r<SimilarDocuments.no_of_shingles;r++){
					random_hash[r][c]=numbers.get(r);
				}
			}
			for (int r = 0; r < SimilarDocuments.no_of_shingles; r++) {
				for (int c = 0; c < SimilarDocuments.no_of_hash; c++) {
					fw.write(random_hash[r][c] + "\t");
				}
				fw.write("\n");
			}
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
